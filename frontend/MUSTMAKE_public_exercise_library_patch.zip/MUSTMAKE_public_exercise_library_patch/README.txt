MUSTMAKE public exercise library patch

Contains only the frontend files changed for this feature.

Files:
- frontend/pages/index.html (updated public dashboard and library markup)
- frontend/js/features/exercises/exercise-library.js (new 39-exercise data library, search, filters, instructions)
- frontend/js/features/workouts/script.js (dashboard no longer redirects logged-out visitors; personal data remains authenticated)
- frontend/js/shared/navbar.js (public navigation for logged-out visitors)
- frontend/assets/css/style.css (responsive styling)

Apply:
1. Back up your current project.
2. Extract this ZIP into your project root (the folder containing frontend/ and backend/), merging/replacing the listed files.
3. Test locally: open the frontend root and visit /today while logged out, then log in and verify today's workouts, history, and streak.
4. Commit and push the frontend changes. Vercel should deploy the frontend normally.

No backend files or Vercel routing configuration are changed. Exercise content is public static educational content. Personal workout APIs are not made public.
